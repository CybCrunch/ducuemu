print("Lua file test")
x = 42
